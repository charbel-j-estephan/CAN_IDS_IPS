FPGA test handout, 22 Nov 2026

1. Unzip this folder's CONTENTS into Desktop\CAN_IDS_IPS and say yes to
   overwrite. The folders inside match the project folders. (On Charbel's
   laptop this is already done.)
2. Open docs\FPGA_TEST_GUIDE.html in Chrome or Edge and follow it top to
   bottom. It tells you which switch to set, which command to run, what you
   should see, and where to write the numbers.
3. Everything runs from fpga_tests.bat in the project folder.

What is new
  - SW2 strict vote on the FPGA (Verilog changes in updatable fpgas\rtl).
    Needs one Quartus build, the guide's section 3.
  - --recover for mixed runs with the FPGA as IPS (python\replay_dataset.py,
    python\run_check.py).
  - python\fp_test.py --fpga and data\fp_test: the false flag test.
  - updatable fpgas\python\push_p6.py: the live 6 byte model update.
  - CHANGES.patch: every code change as one git diff, for review.

Never zip or share updatable fpgas\quartus, keys or master.key.
